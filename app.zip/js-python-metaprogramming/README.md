# Metaprogramming in Python & JavaScript

Here you have my presentation for the [DEVCON1](https://twitter.com/search?q=%23devcon1&src=typd), **Metaprogramming in Python & JavaScript**.

The presentation is a comparison between both programming languages, specially its function model and present some interesting toppics:

 * Evaluation of strings as programs
 * Decorators
 * DRY interfaces
 * Dynamic runtime data models (Live APIs)
 * On the fly methods
